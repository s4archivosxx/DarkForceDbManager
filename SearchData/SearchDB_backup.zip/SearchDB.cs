﻿using System;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;
using System.Drawing;

namespace SearchData
{
    public partial class SearchDB : Form
    {
        //DateTimeOffset PurchaseDate = new DateTimeOffset().AddSeconds(double .MaxValue);
        IniFile iniSI = new IniFile("SearchData.ini");
        IniFile iniSIV3 = new IniFile("SendItemsV3.ini");
        IniFile iniLog = new IniFile("Log.ini");
        private string ErrorNickname = "No se ha podido encontrar el nickname.";
        private string ErrorItemId = "No se ha podido encontrar el ItemId.";
        private string ErrorAcountId = "No se ha podido encontrar el accountId.";
        private string NicknameVacío = "Asegúrese que no esté vacía la casilla de Nickname.";
        private string AccountIdVacío = "Asegúrese que no esté vacía la casilla de AccountId.";
        private string ShopItemVacío = "Asegúrese que no esté vacía la casilla de ShopItemId.";
        private string PriceGroupIdVacío = "Asegúrese que no esté vacía la casilla de PriceGroupId.";
        //string EffectVacío = "Asegúrese que no esté vacía la casilla de Effect.";
        //string ColorVacío = "Asegúrese que no esté vacía la casilla de Color.";
        private string NormalAccount = "Esta cuanta se encuentra libre de un bloqueo.";
        private string ErrorEffectGroupId = "No se ha podido encontrar el EffectGroupId del item.";
        private string ErrorNamePrice = "No se ha podido encontrar el NamePrice del item.";
        private string IdVacío = "Asegúrese que no esté vacía la casilla de Id.";
        private string CasillasVacías = "Asegúrese de que algunas casillas no estén vacías";
        bool mauseaction;
        Point point;
        private string nw = Environment.NewLine;

        MySqlConnection con = new MySqlConnection($"server=158.69.101.201;port=3306;username=s4new;password=s4new");
        //MySqlConnection con = new MySqlConnection($"server=localhost;port=3306;username=root;password=adminjordan");
        MySqlCommand cmd;
        MySqlDataReader mdr;


        private void LoadConfig()
        {
            try
            {

                txtbId.Text = iniSI.Read("Id", "SAVED");
                //lblPurchaseDate.Text = iniSI.Read("PurchaseDate", "SAVED");
                txtbAccountId.Text = iniSI.Read("AccountId", "SAVED");
                txtboxNM.Text = iniSI.Read("Nickname", "SAVED");
                txtbU.Text = iniSI.Read("Username", "SAVED");
                #region Comments
                //int value = int.Parse(txtbId.Text);
                //int value2 = 1;
                //value = value + value2;
                //txtbId.Text = "" + value;

                //using (StreamReader rt = new StreamReader("LogId.log"))
                //{
                //    txtbId.Text = rt.ReadToEnd();
                //    int value = Convert.ToInt32(txtbId.Text);
                //    int value2 = 1;
                //    value = value + value2;
                //    txtbId.Text = "" + value;
                //    txtbId.Update();
                //}
                //string[] LoadId = File.ReadAllLines("LogId.log");
                //txtbId.Text = LoadId[0];
                #endregion

            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show($"Error: {ex.Message}", "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public SearchDB()
        {
            InitializeComponent();
            MenuSendAp.Click += SendAp;
            MenuSendPen.Click += SendPen;
            MenuSendNivel.Click += SendLvl;
        }

        private void SendAp(object sender, EventArgs e)
        {
            if (txtbAccountId.Text == "")
            {
                MessageBox.Show("Inserta AccountId para enviar AP", "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (txtbAP.Text == "")
            {
                MessageBox.Show("Falta Insertar el AP", "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (LabelUserAP.Text == "")
            {
                MessageBox.Show("Falta Insertar el AP", "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            #region Operation
            int v = int.Parse(txtbAP.Text);
            int uv = int.Parse(LabelUserAP.Text);
            v = v + uv;
            #endregion

            #region Time
            var sec = DateTime.Now.Second;
            #endregion

            try
            {
                string Query = "UPDATE s4game.players SET Id='" + txtbAccountId.Text + "',AP='" + v.ToString() + "' where Id='" + txtbAccountId.Text + "';";

                cmd = new MySqlCommand(Query, con);

                con.Open();
                mdr = cmd.ExecuteReader();
                if (mdr.Read()) { }
                con.Close();
                NewLogAPSent();
                File.WriteAllText($"Logs\\Log_AP_SENT_{txtboxNM.Text}_{sec}.txt", $"[AP ENVIADO[{txtbAccountId.Text}]]{nw}A: {txtboxNM.Text}{nw}Cantidad: {txtbAP.Text}{nw}AP Anterior: {LabelUserAP.Text}{nw}AP Actual: {v}{nw}Fecha: {DateTime.Now}{nw}Por: {CompanyName}");
                MessageBox.Show($"[AP ENVIADO[{txtbAccountId.Text}]]\nA: {txtboxNM.Text}\nCantidad: {txtbAP.Text}\nAP Anterior: {LabelUserAP.Text}\nAP Actual: {v}\nPor: {CompanyName}", "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //LabelUserAP.Text = v.ToString();
                LabelUserAP.Text = "";
                txtbAP.Text = "";
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message, "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void NewLogAPSent()
        {
            var sec = DateTime.Now.Second;

            iniLog.Write("AccountId", txtbAccountId.Text, $"AP_SENT_{txtbAccountId.Text}_{sec}");
            iniLog.Write("Username", txtbU.Text, $"AP_SENT_{txtbAccountId.Text}_{sec}");
            iniLog.Write("Nickname", txtboxNM.Text, $"AP_SENT_{txtbAccountId.Text}_{sec}");
            iniLog.Write("AP", txtbAP.Text, $"AP_SENT_{txtbAccountId.Text}_{sec}");
            iniLog.Write("Fecha", DateTime.Now.ToString(), $"AP_SENT_{txtbAccountId.Text}_{sec}");
            iniLog.Write("Envío", bool.TrueString, $"AP_SENT_{txtbAccountId.Text}_{sec}");
        }

        private void SendPen(object sender, EventArgs e)
        {
            if (txtbAccountId.Text == "")
            {
                MessageBox.Show("Inserta AccountId para enviar AP", "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (txtbPen.Text == "")
            {
                MessageBox.Show("Falta Insertar el PEN", "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (LabelUserPEN.Text == "")
            {
                MessageBox.Show("Falta Insertar el PEN", "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            #region Operation
            int v = int.Parse(txtbPen.Text);
            int uv = int.Parse(LabelUserPEN.Text);
            v = v + uv;
            #endregion

            #region Time
            var sec = DateTime.Now.Second;
            #endregion

            try
            {
                string Query = "UPDATE s4game.players SET Id='" + txtbAccountId.Text + "',PEN='" + v.ToString() + "' where Id='" + txtbAccountId.Text + "';";

                cmd = new MySqlCommand(Query, con);

                con.Open();
                mdr = cmd.ExecuteReader();
                if (mdr.Read()) { }
                con.Close();
                NewLogPENSent();
                File.WriteAllText($"Logs\\Log_PEN_SENT_{txtboxNM.Text}_{sec}.txt", $"[PEN ENVIADO[{txtbAccountId.Text}]]{nw}A: {txtboxNM.Text}{nw}Cantidad: {txtbPen.Text}{nw}PEN Anterior: {LabelUserPEN.Text}{nw}PEN Actual: {v}{nw}Fecha: {DateTime.Now}{nw}Por: {CompanyName}");
                MessageBox.Show($"[PEN ENVIADO[{txtbAccountId.Text}]]\nA: {txtboxNM.Text}\nCantidad: {txtbPen.Text}\nPEN Anterior: {LabelUserPEN.Text}\nPEN Actual: {v}\nPor: {CompanyName}", "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LabelUserPEN.Text = "";
                txtbPen.Text = "";
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message, "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void NewLogPENSent()
        {
            var sec = DateTime.Now.Second;

            iniLog.Write("AccountId", txtbAccountId.Text, $"PEN_SENT_{txtbAccountId.Text}_{sec}");
            iniLog.Write("Username", txtbU.Text, $"PEN_SENT_{txtbAccountId.Text}_{sec}");
            iniLog.Write("Nickname", txtboxNM.Text, $"PEN_SENT_{txtbAccountId.Text}_{sec}");
            iniLog.Write("AP", txtbAP.Text, $"PEN_SENT_{txtbAccountId.Text}_{sec}");
            iniLog.Write("Fecha", DateTime.Now.ToString(), $"PEN_SENT_{txtbAccountId.Text}_{sec}");
            iniLog.Write("Envío", bool.TrueString, $"PEN_SENT_{txtbAccountId.Text}_{sec}");
        }

        private void SendLvl(object sender, EventArgs e)
        {
            if (txtbAccountId.Text == "")
            {
                MessageBox.Show("Falta Insertar AccountId", "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (txtbLvl.Text == "")
            {
                MessageBox.Show("Falta Insertar Lvl", "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (txtbExperience.Text == "")
            {
                MessageBox.Show("Falta Insertar TotalExperience", "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            #region Restrictions
            //else if (IdTextBox.Text == "3")
            //{
            //    MessageBox.Show("No puedes editar el LVL de un [ADMIN]", "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}
            //else if (IdTextBox.Text == "1254")
            //{
            //    MessageBox.Show("No puedes editar el LVL de un [ADMIN]", "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}
            //else if (IdTextBox.Text == "18")
            //{
            //    MessageBox.Show("No puedes editar el LVL de un [GM]", "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}
            //else if (IdTextBox.Text == "839")
            //{
            //    MessageBox.Show("No puedes editar el LVL de un [GM]", "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}
            //else if (IdTextBox.Text == "78")
            //{
            //    MessageBox.Show("No puedes editar el LVL de un [GM]", "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}
            //else if (IdTextBox.Text == "82")
            //{
            //    MessageBox.Show("No puedes editar el LVL de un [GM]", "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}
            //else if (IdTextBox.Text == "838")
            //{
            //    MessageBox.Show("No puedes editar el LVL de un [GM]", "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}
            //else if (IdTextBox.Text == "550")
            //{
            //    MessageBox.Show("No puedes editar el LVL de un [GM]", "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}
            //else if (IdTextBox.Text == "557")
            //{
            //    MessageBox.Show("No puedes editar el LVL de un [GM]", "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}
            //else if (IdTextBox.Text == "578")
            //{
            //    MessageBox.Show("No puedes editar el LVL de un [GM]", "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}
            //else if (IdTextBox.Text == "971")
            //{
            //    MessageBox.Show("No puedes editar el LVL de un [GM]", "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}
            //else if (IdTextBox.Text == "1001")
            //{
            //    MessageBox.Show("No puedes editar el LVL de un [GM]", "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}
            //else if (IdTextBox.Text == "1278")
            //{
            //    MessageBox.Show("No puedes editar el LVL de un [GM]", "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}
            //else if (IdTextBox.Text == "1620")
            //{
            //    MessageBox.Show("No puedes editar el LVL de un [GM]", "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}
            //else if (IdTextBox.Text == "1694")
            //{
            //    MessageBox.Show("No puedes editar el LVL de un [GM]", "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}
            //else if (IdTextBox.Text == "780")
            //{
            //    MessageBox.Show("No puedes editar el LVL de este usuario", "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}
            //else if (IdTextBox.Text == "1350")
            //{
            //    MessageBox.Show("No puedes editar el LVL de un [GM]", "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}
            //else if (IdTextBox.Text == "2127")
            //{
            //    MessageBox.Show("No puedes editar el LVL de este usuario", "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}
            //else if (IdTextBox.Text == "2126")
            //{
            //    MessageBox.Show("No puedes editar el LVL de este usuario", "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}
            //else if (cmblvl.Text == "")
            //{
            //    MessageBox.Show("Falta Insertar Lvl", "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}
            //else if (cmbTX.Text == "")
            //{
            //    MessageBox.Show("Falta Insertar TotalExperience", "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}
            //else if (IdTextBox.Text == "1474")
            //{
            //    MessageBox.Show("No puedes editar el LVL de un [GM]", "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}
            //else if (IdTextBox.Text == "5934")
            //{
            //    MessageBox.Show("No puedes editar el LVL de un [GM]", "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}
            //else if (cmbTX.Text == "63703100")
            //{
            //    MessageBox.Show("No es posible enviar esa EXP", "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}
            //else if (cmbTX.Text == "")
            //{
            //    MessageBox.Show("Falta Insertar TotalExperience", "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}
            #endregion

            #region Time
            var sec = DateTime.Now.Second;
            #endregion

            try
            {
                string Query = "UPDATE s4game.players SET Id='" + txtbAccountId.Text + "',Level='" + txtbLvl.Text + "',TotalExperience='" + txtbExperience.Text + "' WHERE Id='" + txtbAccountId.Text + "';";
                cmd = new MySqlCommand(Query, con);

                con.Open();
                mdr = cmd.ExecuteReader();
                if (mdr.Read()) { }
                con.Close();
                NewLogSendLvl();
                File.WriteAllText($"Logs\\Log_Lvl_Updated_{txtboxNM.Text}_{sec}.txt", $"[NIVEL EDITADO[{txtbAccountId.Text}]]{nw}A: {txtboxNM.Text}{nw}Nivel Anterior: {LabelUserLvl.Text}{nw}Nivel Actual: {txtbLvl.Text}{nw}Experiencia Actual: {txtbExperience.Text}{nw}Fecha: {DateTime.Now}{nw}Por: {CompanyName}");
                MessageBox.Show($"[NIVEL EDITADO[{txtbAccountId.Text}]]\nA: {txtboxNM.Text}\nNivel Anterior: {LabelUserLvl.Text}\nNivel Actual: {txtbLvl.Text}\nExperiencia Actual: {txtbExperience.Text}\nPor: {CompanyName}", "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtbLvl.Text = "";
                LabelUserLvl.Text = "";
                txtbExperience.Text = "";
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message, "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void NewLogSendLvl()
        {
            var sec = DateTime.Now.Second;

            iniLog.Write("AccountId", txtbAccountId.Text, $"EDIT_LVL_{txtbAccountId.Text}_{sec}");
            iniLog.Write("Username", txtbU.Text, $"EDIT_LVL_{txtbAccountId.Text}_{sec}");
            iniLog.Write("Nickname", txtboxNM.Text, $"EDIT_LVL_{txtbAccountId.Text}_{sec}");
            iniLog.Write("Lvl", txtbLvl.Text, $"EDIT_LVL_{txtbAccountId.Text}_{sec}");
            iniLog.Write("TotalExperience", txtbExperience.Text, $"EDIT_LVL_{txtbAccountId.Text}_{sec}");
            iniLog.Write("Fecha", DateTime.Now.ToString(), $"EDIT_LVL_{txtbAccountId.Text}_{sec}");
            iniLog.Write("Actualizado", bool.TrueString, $"EDIT_LVL_{txtbAccountId.Text}_{sec}");
        }

        private void SearchAccount()
        {
            if (txtboxNM.Text == "")
            {
                MessageBox.Show(NicknameVacío, "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            try
            {
                con.Open();

                string Query = "SELECT * FROM s4auth.accounts WHERE Nickname='" + txtboxNM.Text + "';";
                cmd = new MySqlCommand(Query, con);
                mdr = cmd.ExecuteReader();

                if (mdr.Read())
                {
                    txtbU.Text = mdr.GetString("Username");
                    txtbAccountId.Text = mdr.GetString("Id");

                    iniSI.Write("AccountId", txtbAccountId.Text, "SAVED");
                    iniSI.Write("Nickname", txtboxNM.Text, "SAVED");
                    iniSI.Write("Username", txtbU.Text, "SAVED");
                }
                else
                {
                    con.Close();
                    MessageBox.Show(ErrorNickname, "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                con.Close();
            }
            catch (Exception ex) { con.Close(); MessageBox.Show(ex.Message, "Search Data Base", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
        }

        private void ShowDataAccount()
        {
            if (txtbAccountId.Text == "")
            {
                MessageBox.Show(AccountIdVacío, "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            try
            {
                con.Open();

                string Query = "SELECT * FROM s4game.players WHERE Id='" + txtbAccountId.Text + "';";
                cmd = new MySqlCommand(Query, con);
                mdr = cmd.ExecuteReader();

                if (mdr.Read())
                {
                    txtbLvl.Text = mdr.GetString("Level");
                    txtbExperience.Text = mdr.GetString("TotalExperience");
                    txtbPen.Text = mdr.GetString("PEN");
                    txtbAP.Text = mdr.GetString("AP");
                    LabelUserPEN.Text = mdr.GetString("PEN");
                    LabelUserAP.Text = mdr.GetString("AP");
                    LabelUserLvl.Text = mdr.GetString("Level");
                }
                else
                {
                    con.Close();
                    MessageBox.Show(ErrorAcountId, "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                con.Close();
            }
            catch (Exception ex) { con.Close(); MessageBox.Show(ex.Message, "Search Data Base", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
        }

        private void ShowBeen()
        {
            if (txtbAccountId.Text == "")
            {
                MessageBox.Show(AccountIdVacío, "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            try
            {
                con.Open();

                string Query = "SELECT * FROM s4auth.bans WHERE AccountId='" + txtbAccountId.Text + "';";
                cmd = new MySqlCommand(Query, con);
                mdr = cmd.ExecuteReader();

                if (mdr.Read())
                {
                    txtbDate.Text = mdr.GetString("Date");
                    txtbDuration.Text = mdr.GetString("Duration");
                    lblState.Visible = true;
                }
                else
                {
                    con.Close();
                    MessageBox.Show(NormalAccount, "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    lblState.Visible = false;
                    txtbDate.Text = "";
                    txtbDuration.Text = "";
                    //con.Close();
                }

                con.Close();
            }
            catch (Exception ex) { con.Close(); MessageBox.Show(ex.Message, "Search Data Base", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
        }

        private void SearchItem()
        {
            if (textBoxShopItemId.Text == "")
            {
                MessageBox.Show(ShopItemVacío, "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            try
            {
                con.Open();

                string Query = "SELECT * FROM s4game.shop_iteminfos WHERE ShopItemId='" + textBoxShopItemId.Text + "';";
                cmd = new MySqlCommand(Query, con);
                mdr = cmd.ExecuteReader();

                if (mdr.Read())
                {
                    textBoxItemId.Text = mdr.GetString("Id");
                    textBoxPriceG.Text = mdr.GetString("PriceGroupId");
                    textBoxEffG.Text = mdr.GetString("EffectGroupId");
                }
                else
                {
                    con.Close();
                    MessageBox.Show(ErrorItemId, "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                con.Close();
            }

            catch(Exception ex) { con.Close(); MessageBox.Show(ex.Message, "Search Data Base", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
        }

        private void SearchEff()
        {
            if (textBoxEffG.Text == "")
            {
                MessageBox.Show(ErrorEffectGroupId, "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            try
            {
                con.Open();

                string Query = "SELECT * FROM s4game.shop_effects WHERE EffectGroupId='" + textBoxEffG.Text + "';";
                cmd = new MySqlCommand(Query, con);
                mdr = cmd.ExecuteReader();

                if (mdr.Read())
                {
                    textBoxEff.Text = mdr.GetString("Effect");
                }
                else
                {
                    MessageBox.Show(ErrorEffectGroupId, "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    con.Close();
                }

                con.Close();
            }

            catch (Exception ex) { con.Close(); MessageBox.Show(ex.Message, "Search Data Base", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
        }

        private void SendItemColornull()
        {
           
            if (txtbId.Text == "" || txtbAccountId.Text == "" || textBoxItemId.Text == "" || textBoxPriceG.Text == "" || textBoxEff.Text == "")
            {
                MessageBox.Show(CasillasVacías, "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            #region PurchaseDate
            int DurationInSeconds = 0;
            var duration = TimeSpan.FromSeconds(DurationInSeconds);
            var sec = DateTime.Now.Second;
            #endregion

            try
            {
                string Query = "INSERT INTO s4game.player_items(Id,PlayerId,ShopItemInfoId,ShopPriceId,Effect,Color,PurchaseDate,Durability,Count) VALUES('" + txtbId.Text + "','" + txtbAccountId.Text + "','" + textBoxItemId.Text + "','" + textBoxPriceG.Text + "','" + textBoxEff.Text + "','" + "0" + "','" + DateTimeOffset.Now.Add(duration).ToUnixTimeSeconds().ToString() + "','" + "2400" + "','" + "0" + "');";

                cmd = new MySqlCommand(Query, con);
                //MySqlDataReader MyReader2;

                con.Open();
                mdr = cmd.ExecuteReader();
                if (mdr.Read()) { }
                con.Close();
                File.WriteAllText($"Logs\\Log_Sended_Item_{txtboxNM.Text}_{sec}.txt", $"[ARTÍCULO ENVIADO[{txtbAccountId.Text}]]{nw}A:{txtboxNM.Text}{nw}Id: {txtbId.Text}{nw}ShopItemId: {textBoxShopItemId.Text}{nw}ItemId: {textBoxItemId.Text}{nw}PriceGroups: {textBoxPriceG.Text}{nw}Effect: {textBoxEff.Text}{nw}Color: 0{nw}Por: {CompanyName}");
                LogSendItem();
                MessageBox.Show($"[ARTÍCULO ENVIADO[{txtbAccountId.Text}]]\nA:{txtboxNM.Text}\nId: {txtbId.Text}\nShopItemId: {textBoxShopItemId.Text}\nItemId: {textBoxItemId.Text}\nPriceGroups: {textBoxPriceG.Text}\nEffect: {textBoxEff.Text}\nColor: 0\nPor: {CompanyName}", "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
                int v = int.Parse(txtbId.Text);
                //int v2 = 1;
                v = v + 1;
                txtbId.Text = v.ToString();
                iniSI.Write("Id", txtbId.Text, "SAVED");
                iniSIV3.Write("Id", txtbId.Text,"SAVED");
                //textBoxItemId.Text = "";
                textBoxPriceG.Text = "";
                textBoxEffG.Text = "";
                textBoxEff.Text = "";

            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message, "Search Data Base", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
        }

        private void SendItem()
        {
            if (txtbId.Text == "" || txtbAccountId.Text == "" || textBoxItemId.Text == "" || textBoxPriceG.Text == "" || textBoxEff.Text == "")
            {
                MessageBox.Show(CasillasVacías, "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (TxtbColor.Text == "")
            {
                SendItemColornull();
                //MessageBox.Show(ColorVacío, "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            #region PurchaseDate
            int DurationInSeconds = 0;
            var duration = TimeSpan.FromSeconds(DurationInSeconds);
            var sec = DateTime.Now.Second;
            #endregion

            try
            {
                string Query = "INSERT INTO s4game.player_items(Id,PlayerId,ShopItemInfoId,ShopPriceId,Effect,Color,PurchaseDate,Durability,Count) VALUES('" + txtbId.Text + "','" + txtbAccountId.Text + "','" + textBoxItemId.Text + "','" + textBoxPriceG.Text + "','" + textBoxEff.Text + "','" + TxtbColor.Text + "','" + DateTimeOffset.Now.Add(duration).ToUnixTimeSeconds().ToString() + "','" + "2400" + "','" + "0" + "');";

                cmd = new MySqlCommand(Query, con);

                con.Open();
                mdr = cmd.ExecuteReader();
                if (mdr.Read()) { }
                con.Close();
                //MessageBox.Show($"Item Enviado a " + txtboxNM.Text + "." + "\n" + "Id:" + txtbId.Text + ".", "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
                File.WriteAllText($"Logs\\Log_Sended_Item_{txtboxNM.Text}_{sec}.txt", $"[ARTÍCULO ENVIADO[{txtbAccountId.Text}]]{nw}A:{txtboxNM.Text}{nw}Id: {txtbId.Text}{nw}ShopItemId: {textBoxShopItemId.Text}{nw}ItemId: {textBoxItemId.Text}{nw}PriceGroups: {textBoxPriceG.Text}{nw}Effect: {textBoxEff.Text}{nw}Color: {TxtbColor.Text}{nw}Por: {CompanyName}");
                LogSendItem();
                MessageBox.Show($"[ARTÍCULO ENVIADO[{txtbAccountId.Text}]]\nA:{txtboxNM.Text}\nId: {txtbId.Text}\nShopItemId: {textBoxShopItemId.Text}\nItemId: {textBoxItemId.Text}\nPriceGroups: {textBoxPriceG.Text}\nEffect: {textBoxEff.Text}\nColor: {TxtbColor.Text}\nPor: {CompanyName}", "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
                int v = int.Parse(txtbId.Text);
                v = v + 1;
                txtbId.Text = v.ToString();
                iniSI.Write("Id", txtbId.Text, "SAVED");
                iniSIV3.Write("Id", txtbId.Text, "SAVED");
                textBoxPriceG.Text = "";
                textBoxEffG.Text = "";
                textBoxEff.Text = "";

                #region comments
                //using (StreamWriter rw = new StreamWriter("LogId.log"))
                //{
                //    rw.Write(txtbId.Text);
                //    rw.Close();
                //    rw.Dispose();
                //}
                //if (btnSndItm.Text == "Enviar :3")
                //{
                //    int id = +1;
                //    textbId.Text = textbId.Text + id;
                //}
                #endregion
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message, "Search Data Base", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
        }

        private void LogSendItem()
        {
            #region Envío Old
            //fi.Create();
            //using (fs = File.Create(".\\Logs\\Log_SentItem_" + txtbId.Text + ".log"))
            //{

            //}
            //ini.Write("=================SearchData=================\n\n============================================\n");
            //using (StreamWriter rw = new StreamWriter(".\\Logs\\Log_SentItem_" + txtbId.Text + ".log"))
            //{
            //    rw.Write("=================SearchData=================\n\n============================================\n");
            //    rw.Write("==============Item Sent to==================\n");
            //    rw.Write("AccountId: " + txtbAccountId.Text + "\n");
            //    rw.Write("Nickname: " + txtboxNM.Text + "\n");
            //    rw.Write("Username: " + txtbU.Text + "\n");
            //    rw.Write("Id: " + txtbId.Text + "\n");
            //    rw.Write("Color: " + TxtbColor.Text + "\n");
            //    rw.Write("ShopItemId: " + textBoxShopItemId.Text + "\n");
            //    rw.Write("ItemId: " + textBoxItemId.Text + "\n");
            //    rw.Write("PriceGroupId: " + textBoxPriceG.Text + "\n");
            //    rw.Write("EffectGroupId: " + textBoxEffG.Text + "\n");
            //    rw.Write("Effect: " + textBoxEff.Text + "\n");
            //    rw.Write("NamePrice: " + txtbNP.Text + "\n");
            //    rw.Write("Fecha Y Hora: " + DateTime.Now + "\n");
            //    rw.Write("Enviado Correctamente\n");
            //    rw.Write("============================================");
            //    rw.Write("\n");
            //    rw.Close();
            //    rw.Dispose();
            //}
            #endregion

            iniLog.Write("AccountId", txtbAccountId.Text, $"ITEMSENT_{textBoxItemId.Text}_ACC{txtbAccountId.Text}_Id{txtbId.Text}");
            iniLog.Write("Nickname", txtboxNM.Text, $"ITEMSENT_{textBoxItemId.Text}_ACC{txtbAccountId.Text}_Id{txtbId.Text}");
            iniLog.Write("Username", txtbU.Text, $"ITEMSENT_{textBoxItemId.Text}_ACC{txtbAccountId.Text}_Id{txtbId.Text}");
            iniLog.Write("Id", txtbId.Text, $"ITEMSENT_{textBoxItemId.Text}_ACC{txtbAccountId.Text}_Id{txtbId.Text}");
            iniLog.Write("Color", TxtbColor.Text, $"ITEMSENT_{textBoxItemId.Text}_ACC{txtbAccountId.Text}_Id{txtbId.Text}");
            iniLog.Write("ShopItemId", textBoxShopItemId.Text, $"ITEMSENT_{textBoxItemId.Text}_ACC{txtbAccountId.Text}_Id{txtbId.Text}");
            iniLog.Write("ItemId", textBoxItemId.Text, $"ITEMSENT_{textBoxItemId.Text}_ACC{txtbAccountId.Text}_Id{txtbId.Text}");
            iniLog.Write("PriceGroupId", textBoxPriceG.Text, $"ITEMSENT_{textBoxItemId.Text}_ACC{txtbAccountId.Text}_Id{txtbId.Text}");
            iniLog.Write("EffectGroupId", textBoxEffG.Text, $"ITEMSENT_{textBoxItemId.Text}_ACC{txtbAccountId.Text}_Id{txtbId.Text}");
            iniLog.Write("Effect", textBoxEff.Text, $"ITEMSENT_{textBoxItemId.Text}_ACC{txtbAccountId.Text}_Id{txtbId.Text}");
            iniLog.Write("NamePrice", txtbNP.Text, $"ITEMSENT_{textBoxItemId.Text}_ACC{txtbAccountId.Text}_Id{txtbId.Text}");
            iniLog.Write("Fecha", DateTime.Now.ToString(), $"ITEMSENT_{textBoxItemId.Text}_ACC{txtbAccountId.Text}_Id{txtbId.Text}");
            iniLog.Write("Envío", bool.TrueString, $"ITEMSENT_{textBoxItemId.Text}_ACC{txtbAccountId.Text}_Id{txtbId.Text}");
        }

        private void UpdateItem()
        {
            if (txtbId.Text == "" || txtbAccountId.Text == "" || textBoxItemId.Text == "" || textBoxPriceG.Text == "" || textBoxEff.Text == "" || TxtbColor.Text == "")
            {
                MessageBox.Show(CasillasVacías, "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            #region Time
            var duration = DateTime.Now.Second;
            #endregion

            try
            {
                string Query = "UPDATE s4game.player_items SET Id='" + txtbId.Text + "',PlayerId='" + txtbAccountId.Text + "',ShopItemInfoId='" + textBoxItemId.Text + "',ShopPriceId='" + textBoxPriceG.Text + "',Effect='" + textBoxEff.Text + "',Color='" + TxtbColor.Text + "' WHERE Id='" + txtbId.Text + "';";
                //MySqlCommand MyCommand2 = new MySqlCommand(Query, con);
                cmd = new MySqlCommand(Query, con);
                //MySqlDataReader MyReader2;
                con.Open();
                mdr = cmd.ExecuteReader();
                if (mdr.Read()) { }
                con.Close();
                File.WriteAllText($"Logs\\Log_Item_Upgrade_{duration}.txt", $"[ARTÍCULO ACTUALIZADO[{txtbAccountId.Text}]]{nw}A: {txtboxNM.Text}{nw}Id: {txtbId.Text}{nw}ShopItemId: {textBoxShopItemId.Text}{nw}ItemId: {textBoxItemId.Text}{nw}PriceGroups: {textBoxPriceG.Text}{nw}Effects: {textBoxEff.Text}{nw}Color: {TxtbColor.Text}{nw}Por: {CompanyName}");
                MessageBox.Show($"[ARTÍCULO ACTUALIZADO[{txtbAccountId.Text}]]\nA: {txtboxNM.Text}\nId: {txtbId.Text}\nShopItemId: {textBoxShopItemId.Text}\nItemId: {textBoxItemId.Text}\nPriceGroups: {textBoxPriceG.Text}\nEffects: {textBoxEff.Text}\nColor: {TxtbColor.Text}\nPor: {CompanyName}", "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //LogUpdateItem();
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message, "Search Data Base", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
        }

        private void LogUpdateItem()
        {
            #region Old LogUpdateItem
            //using (StreamWriter rw = new StreamWriter(".\\Logs\\Log_UpdItem_" + txtbId.Text + ".log"))
            //{

            //    rw.Write("=================SearchData=================\n\n============================================\n");
            //    rw.Write("==============Update Item to==================\n");
            //    rw.Write("AccountId: " + txtbAccountId.Text + "\n");
            //    rw.Write("Nickname: " + txtboxNM.Text + "\n");
            //    rw.Write("Username: " + txtbU.Text + "\n");
            //    rw.Write("Id: " + txtbId.Text + "\n");
            //    rw.Write("New Color: " + TxtbColor.Text + "\n");
            //    rw.Write("New ShopItemId: " + textBoxShopItemId.Text + "\n");
            //    rw.Write("New ItemId: " + textBoxItemId.Text + "\n");
            //    rw.Write("New PriceGroupId: " + textBoxPriceG.Text + "\n");
            //    rw.Write("New EffectGroupId: " + textBoxEffG.Text + "\n");
            //    rw.Write("New Effect: " + textBoxEff.Text + "\n");
            //    rw.Write("New NamePrice: " + txtbNP.Text + "\n");
            //    rw.Write("Fecha Y Hora: " + DateTime.Now + "\n");
            //    rw.Write("Actualizado Correctamente\n");
            //    rw.Write("============================================");
            //    rw.Write("\n");
            //    rw.Close();
            //    rw.Dispose();
            //}
            #endregion

            iniLog.Write("AccountId", txtbAccountId.Text, $"ITEMUPDATE_{textBoxItemId.Text}_ACC{txtbAccountId.Text}_Id{txtbId.Text}");
            iniLog.Write("Nickname", txtboxNM.Text, $"ITEMUPDATE_{textBoxItemId.Text}_ACC{txtbAccountId.Text}_Id{txtbId.Text}");
            iniLog.Write("Id", txtbId.Text, $"ITEMUPDATE_{textBoxItemId.Text}_ACC{txtbAccountId.Text}_Id{txtbId.Text}");
            iniLog.Write("NewColor", TxtbColor.Text, $"ITEMUPDATE_{textBoxItemId.Text}_ACC{txtbAccountId.Text}_Id{txtbId.Text}");
            iniLog.Write("NewShopItemId", textBoxShopItemId.Text, $"ITEMUPDATE_{textBoxItemId.Text}_ACC{txtbAccountId.Text}_Id{txtbId.Text}");
            iniLog.Write("NewItemId", textBoxItemId.Text, $"ITEMUPDATE_{textBoxItemId.Text}_ACC{txtbAccountId.Text}_Id{txtbId.Text}");
            iniLog.Write("NewPriceGroupId", textBoxPriceG.Text, $"ITEMUPDATE_{textBoxItemId.Text}_ACC{txtbAccountId.Text}_Id{txtbId.Text}");
            iniLog.Write("NewEffectGroupId", textBoxEffG.Text, $"ITEMUPDATE_{textBoxItemId.Text}_ACC{txtbAccountId.Text}_Id{txtbId.Text}");
            iniLog.Write("NewEffect", textBoxEff.Text, $"ITEMUPDATE_{textBoxItemId.Text}_ACC{txtbAccountId.Text}_Id{txtbId.Text}");
            iniLog.Write("NewNamePrice", txtbNP.Text, $"ITEMUPDATE_{textBoxItemId.Text}_ACC{txtbAccountId.Text}_Id{txtbId.Text}");
            iniLog.Write("Fecha", DateTime.Now.ToString(), $"ITEMUPDATE_{textBoxItemId.Text}_ACC{txtbAccountId.Text}_Id{txtbId.Text}");
            iniLog.Write("Actualización", bool.TrueString, $"ITEMUPDATE_{textBoxItemId.Text}_ACC{txtbAccountId.Text}_Id{txtbId.Text}");
        }

        private void SearchPriceName()
        {
            if (textBoxPriceG.Text == "")
            {
                MessageBox.Show(PriceGroupIdVacío, "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            try
            {
                con.Open();

                string Query = "SELECT * FROM s4game.shop_price_groups WHERE Id='" + textBoxPriceG.Text + "';";
                cmd = new MySqlCommand(Query, con);
                mdr = cmd.ExecuteReader();

                if (mdr.Read())
                {
                    txtbNP.Text = mdr.GetString("Name");
                    //textBoxPriceType.Text = mdr.GetString("PriceType");
                }
                else
                {
                    MessageBox.Show(ErrorNamePrice, "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                con.Close();
            }

            catch (Exception ex) { con.Close(); MessageBox.Show(ex.Message, "Search Data Base", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
        }


        private void SearchDB_Load(object sender, EventArgs e)
        {
            LoadConfig();
        }

        private void OpenFile()
        {
            OpenFileDialog Open = new OpenFileDialog();
            StreamReader myStreamReader;
            Open.Filter = "Log [*.log*]|*.log|Text [*.txt*]|*.txt|All Files [*.*]|*.*";
            Open.CheckFileExists = true;
            Open.Title = "Abrir Archivo";
            Open.ShowDialog();
            try
            {
                Open.OpenFile();
                myStreamReader = File.OpenText(Open.FileName);
                txtbId.Text = myStreamReader.ReadToEnd();
                int v = int.Parse(txtbId.Text);
                int v2 = 1;
                v = v + v2;
                txtbId.Text = v.ToString();
                //txtbId.Update();
                Open.Dispose();
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Search Data Base", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void DeleteItem()
        {
            if (txtbId.Text == "")
            {
                MessageBox.Show(IdVacío, "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            try
            {
                //string MyConnection2 = "server=198.50.218.64;port=3306;username=gmcmd;password=gmcmd";
                string Query = "DELETE FROM s4game.player_items WHERE Id='" + txtbId.Text + "';";
                cmd = new MySqlCommand(Query, con);
                //MySqlDataReader MyReader2;
                con.Open();
                mdr = cmd.ExecuteReader();
                if (mdr.Read()) { }
                con.Close();
                MessageBox.Show($"[ITEM ELIMIADO]\nId: {txtbId.Text}\nPor: {CompanyName}", "S4League Dark Force", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LogDeleteItem();
                //txtbId.Text = "";
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message, "Search Data Base", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void LogDeleteItem()
        {
            #region Old LogDeleteItem
            //using (StreamWriter rw = new StreamWriter(".\\Logs\\Log_DeleteItem_" + txtbId.Text + ".log"))
            //{
            //    rw.Write("=================SearchData=================\n\n============================================\n");
            //    rw.Write("==============Delete Item to==================\n");
            //    rw.Write("Id: " + txtbId.Text + "\n");
            //    rw.Write("Eliminado Correctamente\n");
            //    rw.Write("============================================");
            //    rw.Write("\n");
            //    rw.Close();
            //    rw.Dispose();
            //}
            #endregion

            var sec = DateTime.Now.Second;

            iniLog.Write("Id", txtbId.Text, $"DELETEITEM_{txtbId.Text}_{sec}");
            iniLog.Write("Eliminación", bool.TrueString, $"DELETEITEM_{txtbId.Text}_{sec}");
            iniLog.Write("Fecha", DateTime.Now.ToString(), $"DELETEITEM_{txtbId.Text}_{sec}");
        }

        private void EnviarItem_Click(object sender, EventArgs e)
        {
            SendItem();
        }

        private void ActualizarItem_Click(object sender, EventArgs e)
        {
            UpdateItem();
        }

        private void EliminarItem_Click(object sender, EventArgs e)
        {
            DeleteItem();
        }

        private void BuscarCuenta_Click(object sender, EventArgs e)
        {
            SearchAccount();
        }

        private void BuscarEfecto_Click(object sender, EventArgs e)
        {
            SearchEff();
        }

        private void BuscarPrecio_Click(object sender, EventArgs e)
        {
            SearchPriceName();
        }

        private void BuscarItem_Click(object sender, EventArgs e)
        {
            SearchItem();
        }

        private void VerEstadoCuenta_Click(object sender, EventArgs e)
        {
            ShowBeen();
        }

        private void VerDatosCuenta_Click(object sender, EventArgs e)
        {
            ShowDataAccount();
        }

        private void AbrirArchivo_Click(object sender, EventArgs e)
        {
            OpenFile();
        }

        private void MenuStrip_MouseDown(object sender, MouseEventArgs e)
        {
            point = new Point(Cursor.Position.X - Location.X, Cursor.Position.Y - Location.Y);
            mauseaction = true;
        }

        private void MenuStrip_MouseMove(object sender, MouseEventArgs e)
        {
            if (mauseaction == true)
            {
                Location = new Point(Cursor.Position.X - point.X, Cursor.Position.Y - point.Y);
            }
        }

        private void MenuStrip_MouseUp(object sender, MouseEventArgs e)
        {
            mauseaction = false;
        }

        private void SearchDB_MouseDown(object sender, MouseEventArgs e)
        {
            point = new Point(Cursor.Position.X - Location.X, Cursor.Position.Y - Location.Y);
            mauseaction = true;
        }

        private void SearchDB_MouseMove(object sender, MouseEventArgs e)
        {
            if (mauseaction == true)
            {
                Location = new Point(Cursor.Position.X - point.X, Cursor.Position.Y - point.Y);
            }
        }

        private void SearchDB_MouseUp(object sender, MouseEventArgs e)
        {
            mauseaction = false;
        }

        private void MenuExit_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
